#!/bin/bash

mkdir -p /var/www/cobbler/autoinstall/system;
rm -rf /var/www/cobbler/autoinstall/system/*;

for s in /var/lib/tftpboot/pxelinux.cfg/01-*; do
	if grep -q 'nocloud-net' $s; then 
		hn=$(grep -oE 'hostname=[^ ]+' $s | sed 's/hostname=//');
		http_server=$(grep -oE 'url=http://[^/]+' $s | sed 's/url=//');
		mkdir -p /var/www/cobbler/autoinstall/system/$hn;
		curl $http_server/cblr/svc/op/autoinstall/system/$hn -o /var/www/cobbler/autoinstall/system/$hn/user-data;
		touch /var/www/cobbler/autoinstall/system/$hn/meta-data;
		touch /var/www/cobbler/autoinstall/system/$hn/vendor-data;
	fi
done
